<?php 
// tự động chuyển hướng sang thư mục client
header('location: client/');