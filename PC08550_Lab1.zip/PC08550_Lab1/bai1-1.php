<?php
// ví dụ về xuất chuỗi

echo "Bài 1: Xuất chuỗi <br> <br> ";
echo "hello <br>";

echo " hello <br>";

echo "hello word <br>";

echo 'hello', 'word' ."<br> <br>" ;

//ví dụ về xuất biến

$str = "hello string ";
$x = 200;
$y = 40.6;

echo "Bài 2: Xuất biến <br> <br>";
echo "string is : $str <br>";
echo "integer is : $x <br>";

echo "float is : $y <br> <br>";

//ví dụ về xuất chuỗi và biến

$color = 'red';

echo 'Bài 3: xuất chuỗi và biến ' . '<br>' . '<br>';
echo 'my car is :' . $color . '<br>';
echo 'my house is : ' . $color . '<br>';
echo 'my boat is : ' . $color . '<br>';


