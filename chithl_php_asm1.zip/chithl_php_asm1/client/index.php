<!-- Thêm file header.php  -->
<?php
include 'header.php';
?>


<!-- Nội dung trang chủ  -->
<div class="text-center">
    <h1>Đây là trang chủ Client</h1>
    <a href="../admin/">Truy cập vào Admin</a>
</div>


<!-- Thêm file footer  -->
<?php
include 'footer.php';
?>