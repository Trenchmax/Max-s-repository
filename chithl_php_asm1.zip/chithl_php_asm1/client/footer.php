<footer>
    <div class="text-center">
        Đây là footer, copyright &copy; Chithl
    </div>
</footer>

</body>
</html>