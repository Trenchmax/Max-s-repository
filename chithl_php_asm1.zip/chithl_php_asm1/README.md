
Cách 1:
- Để code vào thư mục C:\Program Files\Ampps\www
- Truy cập vào trang web: 
    + Client: http://localhost/chithl_php_asm1/
    + Admin: http://localhost/chithl_php_asm1/admin/

Cách 2:
- Để code vào thư mục mong muốn
- Thực thiện thêm domain của Ampps
- Truy cập vào trang web:
    + Client: http://ten_domain
    + Admin: http://ten_domaim/admin/ 

